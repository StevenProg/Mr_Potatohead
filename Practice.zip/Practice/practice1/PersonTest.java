class Person {

   // Properties of the class...
   private String name;
   public int    age;
   private int    length;


   // Methods of the class...
   public void talk() {
      System.out.println("Hi, my name's " + name);
      System.out.println(", my age is " + age);
      System.out.println("and my length is " + length);
      commentAboutAge();
   }
   public void commentAboutAge() {
      if (age < 5) {
         System.out.println("baby");
      }
      if (age == 5) {
         System.out.println("time to start school");
      }
      if (age > 60) {
         System.out.println("oldy");
      }
   }
   public void growOlder() {
      age = age + 1;
   }
   public void growOlderBy(int years) {
      age = age + years;
   }
   public void makeKing() {
      name = "king " + name;
   }

}

class PersonTest {

   // The main method is the point of entry into the program...
   public static void main(String[] args) {

      Person ls = new Person();
      Person wp = new Person();

      wp.growOlder();
      ls.growOlderBy(10);
      ls.makeKing();
      wp.talk();
      ls.talk();
      System.out.println(ls.age);

   }

}
